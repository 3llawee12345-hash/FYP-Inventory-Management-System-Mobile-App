# Inventory Management System

A simple web-based inventory management system built with HTML, CSS, JavaScript, and Node.js.
