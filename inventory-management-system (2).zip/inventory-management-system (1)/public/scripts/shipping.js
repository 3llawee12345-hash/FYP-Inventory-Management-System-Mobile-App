document.addEventListener('DOMContentLoaded', () => {
    fetchShipments();
    document.querySelector('#openNewShipmentModalBtn').addEventListener('click', openNewShipmentModal);
    document.querySelector('#closeNewShipmentModalBtn').addEventListener('click', closeNewShipmentModal);
    document.querySelector('#createShipmentForm').addEventListener('submit', handleCreateShipmentSubmit);
    document.querySelector('#closeUpdateShipmentModalBtn').addEventListener('click', () => {
      document.getElementById('updateShipmentModal').classList.remove('show');
    });
    document.querySelector('#updateShipmentForm').addEventListener('submit', handleUpdateShipmentSubmit);
    document.querySelector('#confirmDeleteShipmentBtn').addEventListener('click', confirmDeleteShipment);
    document.querySelector('#cancelDeleteShipmentBtn').addEventListener('click', () => {
      document.getElementById('deleteShipmentConfirmModal').classList.remove('show');
    });
  });
  
  async function fetchShipments() {
    try {
      const res = await fetch('/api/shipping');
      const shipments = await res.json();
      const tbody = document.querySelector('#shippingTableBody');
      if (!tbody) return console.error('Table body not found');
      tbody.innerHTML = '';
  
      shipments.forEach(shipment => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${shipment.shipment_id}</td>
          <td>${shipment.order_id}</td>
          <td>${shipment.shipping_method}</td>
          <td>${shipment.quantity}</td>
          <td>${new Date(shipment.due_date).toLocaleDateString()}</td>
          <td><span class="status-badge ${getStatusClass(shipment.status)}">${shipment.status}</span></td>
          <td>${shipment.assigned_to || 'Unassigned'}</td>
          <td>
            <button class='fas fa-eye' onclick='openShipmentModal(${JSON.stringify(shipment)})'></button>
            <button class='fas fa-edit' onclick='openUpdateShipmentModal(${JSON.stringify(shipment)})'></button>
            <button class='fas fa-trash' onclick='openDeleteShipmentModal(${shipment.shipment_id})'></button>
          </td>`;
        tbody.appendChild(row);
      });
    } catch (err) {
      console.error('Error fetching shipments:', err);
    }
  }
  
  function getStatusClass(status) {
    const s = status.toLowerCase();
    if (s === 'pending') return 'pending';
    if (s === 'picking') return 'picking';
    if (s === 'packing') return 'packing';
    if (s === 'ready') return 'ready';
    if (s === 'shipped') return 'shipped';
    return 'default';
  }
  
  // View Modal
  function openShipmentModal(shipment) {
    document.getElementById('shipmentModalTitle').textContent = `Shipment - SHIP-${shipment.shipment_id}`;
    document.getElementById('shipment-order-id').textContent = `Order ID: ${shipment.order_id}`;
    document.getElementById('shipment-method').textContent = `Method: ${shipment.shipping_method}`;
    document.getElementById('shipment-quantity').textContent = `Quantity: ${shipment.quantity}`;
    document.getElementById('shipment-due-date').textContent = `Due Date: ${new Date(shipment.due_date).toLocaleDateString()}`;
    document.getElementById('shipment-status').textContent = shipment.status;
    document.getElementById('shipment-status').className = `status-badge ${getStatusClass(shipment.status)}`;
    document.getElementById('shipmentModal').classList.add('show');
  }
  function closeShipmentModal() {
    document.getElementById('shipmentModal').classList.remove('show');
  }
  
  // Create Modal
  function openNewShipmentModal() {
    document.getElementById('newShipmentModal').classList.add('show');
  }
  function closeNewShipmentModal() {
    document.getElementById('newShipmentModal').classList.remove('show');
  }
  async function handleCreateShipmentSubmit(e) {
    e.preventDefault();
    const order_id = document.getElementById('create_order_id')?.value;
    const shipping_method = document.getElementById('create_shipping_method')?.value;
    const quantity = document.getElementById('create_quantity').value;
    const due_date = document.getElementById('create_due_date')?.value;
    const status = document.getElementById('create_status')?.value;
    const assigned_to = document.getElementById('create_assigned_to')?.value;
  
    if (!order_id || !shipping_method || !due_date || !status) {
      alert('Please fill all required fields.');
      return;
    }
  
    try {
      const res = await fetch('/api/shipping', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_id, shipping_method, quantity, due_date, status, assigned_to })
      });
  
      if (res.ok) {
        alert('Shipment created successfully!');
        closeNewShipmentModal();
        fetchShipments();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to create shipment.');
      }
    } catch (error) {
      console.error('Error creating shipment:', error);
    }
  }
  
  // Update Modal
  function openUpdateShipmentModal(shipment) {
    document.getElementById('update_shipment_id').value = shipment.shipment_id;
    document.getElementById('update_order_id').value = shipment.order_id;
    document.getElementById('update_shipping_method').value = shipment.shipping_method;
    document.getElementById('update_quantity').value = shipment.quantity;
    document.getElementById('update_due_date').value = shipment.due_date.split('T')[0];
    document.getElementById('update_status').value = shipment.status;
    document.getElementById('update_assigned_to').value = shipment.assigned_to || '';
    document.getElementById('updateShipmentModal').classList.add('show');
  }
  
  async function handleUpdateShipmentSubmit(e) {
    e.preventDefault();
    const shipmentId = document.getElementById('update_shipment_id').value;
    const data = {
      order_id: document.getElementById('update_order_id').value,
      shipping_method: document.getElementById('update_shipping_method').value,
      quantity: document.getElementById('update_quantity').value,
      due_date: document.getElementById('update_due_date').value,
      status: document.getElementById('update_status').value,
      assigned_to: document.getElementById('update_assigned_to').value
    };
  
    try {
      const res = await fetch(`/api/shipping/${shipmentId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
  
      if (res.ok) {
        alert('Shipment updated!');
        document.getElementById('updateShipmentModal').classList.remove('show');
        fetchShipments();
      } else {
        alert('Failed to update shipment.');
      }
    } catch (err) {
      console.error('Error updating shipment:', err);
    }
  }
  
  // Delete Modal
  let deleteShipmentId = null;
  function openDeleteShipmentModal(id) {
    deleteShipmentId = id;
    document.getElementById('deleteShipmentConfirmModal').classList.add('show');
  }
  async function confirmDeleteShipment() {
    try {
      const res = await fetch(`/api/shipping/${deleteShipmentId}`, { method: 'DELETE' });
      if (res.ok) {
        alert('Shipment deleted successfully.');
        document.getElementById('deleteShipmentConfirmModal').classList.remove('show');
        fetchShipments();
      } else {
        alert('Failed to delete shipment.');
      }
    } catch (err) {
      console.error('Delete error:', err);
    }
  }
  