
// warehouseInventory.js

document.addEventListener("DOMContentLoaded", () => {
  fetchInventoryLogs();
  fetchInventoryItems();
});

// Fetch and populate inventory logs
async function fetchInventoryLogs() {
  try {
    const res = await fetch("/api/inventory/logs");
    const logs = await res.json();

    const tableBody = document.querySelector("#inventoryLogsTable tbody");
    tableBody.innerHTML = "";

    logs.forEach(log => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${log.log_id}</td>
        <td>${log.product_id}</td>
        <td>${log.change_type}</td>
        <td>${log.quantity_changed}</td>
        <td>${new Date(log.timestamp).toLocaleString()}</td>
        <td>${log.user_id}</td>
      `;
      tableBody.appendChild(row);
    });
  } catch (err) {
    console.error("Error fetching logs:", err);
  }
}

async function fetchInventoryItems() {
  try {
    const response = await fetch("/api/inventory/items");
    const items = await response.json();

    const tbody = document.querySelector("#inventoryTable tbody");
    tbody.innerHTML = "";

    items.forEach(item => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${item.id}</td>
        <td>${item.name}</td>
        <td>${item.sku}</td>
        <td>${item.location}</td>
        <td>${item.quantity}</td>
        <td>${item.status}</td>
        <td>
          <button class="action-btn view-btn" title="View" onclick='openViewModal(${JSON.stringify(item)})'><i class="fas fa-eye"></i></button>
          <button class="action-btn edit-btn" title="Edit" onclick='openEditModal(${JSON.stringify(item)})'><i class="fas fa-edit"></i></button>
          <button class="action-btn adjust-btn" title="Adjust" onclick='openAdjustModal(${item.id})'><i class="fas fa-balance-scale"></i></button>
          <button class="action-btn delete-btn" title="Delete" onclick='confirmDelete(${item.id})'><i class="fas fa-trash-alt"></i></button>
        </td>
      `;
      tbody.appendChild(row);
    });
  } catch (error) {
    console.error("Failed to fetch inventory:", error);
  }
}

function openViewModal(item) {
  const modalBody = document.getElementById("modal-body");
  modalBody.innerHTML = `
    <h3>${item.name}</h3>
    <p><strong>SKU:</strong> ${item.sku}</p>
    <p><strong>Location:</strong> ${item.location}</p>
    <p><strong>Quantity:</strong> ${item.quantity}</p>
    <p><strong>Status:</strong> ${item.status}</p>
  `;
  document.getElementById("inventoryModal").style.display = "block";
}

function openEditModal(item) {
  const body = document.getElementById("modal-body");
  body.innerHTML = `
    <h3>Edit Item: ${item.name}</h3>
    <label>Name: <input id="editName" value="${item.name}"></label><br>
    <label>SKU: <input id="editSku" value="${item.sku || ''}"></label><br>
    <label>Location: <input id="editLocation" value="${item.location}"></label><br>
    <label>Status: 
      <select id="editStatus">
        <option ${item.status === "In Stock" ? "selected" : ""}>In Stock</option>
        <option ${item.status === "Low Stock" ? "selected" : ""}>Low Stock</option>
        <option ${item.status === "Out of Stock" ? "selected" : ""}>Out of Stock</option>
      </select>
    </label><br>
    <button onclick="submitEdit(${item.id})">Save</button>
  `;
  document.getElementById("inventoryModal").style.display = "block";
}

function openAdjustModal(id) {
  const modalBody = document.getElementById("modal-body");
  modalBody.innerHTML = `
    <h3>Adjust Quantity</h3>
    <label for="adjustQty">New Quantity:</label>
    <input type="number" id="adjustQty" min="0" />
    <button onclick="submitAdjustment(${id})">Submit</button>
  `;
  document.getElementById("inventoryModal").style.display = "block";
}

function confirmDelete(id) {
  const body = document.getElementById("modal-body");
  body.innerHTML = `
    <h3>Confirm Deletion</h3>
    <p>Are you sure you want to delete this item?</p>
    <button onclick="deleteItem(${id})">Yes, Delete</button>
    <button onclick="closeModal()">Cancel</button>
  `;
  document.getElementById("inventoryModal").style.display = "block";
}

function closeModal() {
  document.getElementById("inventoryModal").style.display = "none";
}

async function submitEdit(id) {
  const name = document.getElementById('editName').value;
  const sku = document.getElementById('editSku').value;
  const location = document.getElementById('editLocation').value;
  const status = document.getElementById('editStatus').value;
  const token = localStorage.getItem('token');

  try {
    const res = await fetch(`/api/inventory/items/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ name, sku, location, status })
    });
    if (!res.ok) throw new Error('Edit failed');
    closeModal();
    fetchInventoryItems();
  } catch (err) {
    alert(err.message);
    console.error('submitEdit error:', err);
  }
}

async function submitAdjustment(id) {
  const qty = document.getElementById('adjustQty').value;
  const token = localStorage.getItem('token');
  try {
    const res = await fetch(`/api/inventory/items/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ quantity: qty }) // Only send quantity
    });

    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.error || 'Adjustment failed');
    }

    closeModal();
    fetchInventoryItems();
    fetchInventoryLogs();
  } catch (err) {
    alert(err.message);
    console.error('submitAdjustment error:', err);
  }
}


async function deleteItem(id) {
  const token = localStorage.getItem('token');

  try {
    const res = await fetch(`/api/inventory/items/${id}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
    if (!res.ok) throw new Error('Delete failed');
    closeModal();
    fetchInventoryItems();
  } catch (err) {
    alert(err.message);
    console.error('deleteItem error:', err);
  }
}
