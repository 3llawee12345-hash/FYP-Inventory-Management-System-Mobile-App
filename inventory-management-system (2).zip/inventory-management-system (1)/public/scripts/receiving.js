document.addEventListener('DOMContentLoaded', () => {
  fetchReceipts();
});

// Fetch Receipts and Display in Table
async function fetchReceipts() {
  try {
    const response = await fetch('/api/receiving');
    const receipts = await response.json();
    const tbody = document.querySelector('#receivingTableBody');

    if (!tbody) {
      console.error('Table body not found');
      return;
    }

    tbody.innerHTML = '';

    receipts.forEach(receipt => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${receipt.receipt_id}</td>
        <td>${receipt.order_id}</td>
        <td>${receipt.supplier_name}</td>
        <td>${new Date(receipt.expected_date).toLocaleDateString()}</td>
        <td>${receipt.quantity}</td>
        <td>${receipt.status}</td>
        <td>${receipt.assigned_to || 'Unassigned'}</td>
        <td>
          <button class="action-btn view-btn" title="View Details" onclick='openReceiptModal(${JSON.stringify(receipt)})'>
            <i class="fas fa-eye"></i>
          </button>
          <button onclick='openUpdateModal(${JSON.stringify(receipt)})' class='fas fa-edit'></button>
          <button onclick='openDeleteModal(${receipt.receipt_id})' class='fas fa-trash'></button>
        </td>
      `;
      tbody.appendChild(row);
    });
  } catch (error) {
    console.error('Error fetching receipts:', error);
  }
}

// Open Receipt Details Modal
function openReceiptModal(receipt) {
  document.getElementById('modal-title').textContent = `Receipt Details - REC-${receipt.receipt_id}`;
  document.getElementById('receipt-number').textContent = `Receipt #REC-${receipt.receipt_id}`;
  document.getElementById('po-number').textContent = `PO-${receipt.order_id}`;
  document.getElementById('supplier-info').textContent = `Supplier: ${receipt.supplier_name}`;
  document.getElementById('expected-date').textContent = `Expected Date: ${new Date(receipt.expected_date).toLocaleDateString()}`;
  document.getElementById('receipt-quantity').textContent = `Quantity: ${receipt.quantity}`;
  document.getElementById('receipt-status').textContent = receipt.status;
  document.getElementById('receipt-status').className = `status-badge ${getStatusClass(receipt.status)}`;

  document.getElementById('receiptModal').classList.add('show');
}

// Close Receipt Modal
function closeReceiptModal() {
  document.getElementById('receiptModal').classList.remove('show');
}

// Get CSS Class Based on Status
function getStatusClass(status) {
  const s = status.toLowerCase();
  if (s === 'Pending') return 'Pending';
  if (s === 'Processing') return 'Processing';
  if (s === 'Completed') return 'Completed';
  if (s === 'Issues') return 'Issues';
  return 'default';
}

// Open Update Modal
function openUpdateModal(receipt) {
  document.getElementById('update_receipt_id').value = receipt.receipt_id;
  document.getElementById('update_order_id').value = receipt.order_id;
  document.getElementById('update_supplier_name').value = receipt.supplier_name;
  document.getElementById('update_expected_date').value = receipt.expected_date.split('T')[0];
  document.getElementById('update_quantity').value = receipt.quantity;
  document.getElementById('update_status').value = receipt.status;
  document.getElementById('update_assigned_to').value = receipt.assigned_to || '';

  document.getElementById('updateReceiptModal').classList.add('show');
}

// Close Update Modal
document.getElementById('closeUpdateModalBtn').addEventListener('click', () => {
  document.getElementById('updateReceiptModal').classList.remove('show');
});

// Handle Update Form Submission
document.getElementById('updateReceiptForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  const data = {
    order_id: document.getElementById('update_order_id').value,
    supplier_name: document.getElementById('update_supplier_name').value,
    expected_date: document.getElementById('update_expected_date').value,
    quantity: parseInt(document.getElementById('update_quantity').value, 10),
    status: document.getElementById('update_status').value,
    assigned_to: document.getElementById('update_assigned_to').value
  };
  const id = document.getElementById('update_receipt_id').value;

  const res = await fetch(`/api/receiving/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });

  if (res.ok) {
    alert('Receipt updated successfully!');
    document.getElementById('updateReceiptModal').classList.remove('show');
    fetchReceipts();
  } else {
    alert('Failed to update receipt.');
  }
});

// Open Delete Confirmation Modal
let deleteReceiptId = null;
function openDeleteModal(receiptId) {
  deleteReceiptId = receiptId;
  document.getElementById('deleteConfirmModal').classList.add('show');
}

// Handle Confirm Delete
document.getElementById('confirmDeleteBtn').addEventListener('click', async () => {
  const res = await fetch(`/api/receiving/${deleteReceiptId}`, { method: 'DELETE' });

  if (res.ok) {
    alert('Receipt deleted successfully!');
    document.getElementById('deleteConfirmModal').classList.remove('show');
    fetchReceipts();
  } else {
    alert('Failed to delete receipt.');
  }
});

// Handle Cancel Delete
document.getElementById('cancelDeleteBtn').addEventListener('click', () => {
  document.getElementById('deleteConfirmModal').classList.remove('show');
});

document.getElementById('newReceivingBtn').addEventListener('click', () => {
  openModal('newReceivingModal');
});

document.getElementById('newReceivingForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const data = {
    order_id: document.getElementById('order_id').value,
    supplier_name: document.getElementById('supplier_name').value,
    expected_date: document.getElementById('expected_date').value,
    quantity: document.getElementById('quantity').value,
    status: document.getElementById('status').value,
    assigned_to: document.getElementById('assigned_to').value
  };

  try {
    const res = await fetch('/api/receiving', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    const result = await res.json();
    if (res.ok) {
      alert('Receiving added!');
      closeModal('newReceivingModal');
      fetchReceipts(); // Refresh table
    } else {
      alert('Error: ' + result.error);
    }
  } catch (err) {
    console.error('Error submitting new receiving:', err);
  }
});

