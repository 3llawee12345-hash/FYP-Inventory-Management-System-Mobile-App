// scripts/products.js

document.addEventListener("DOMContentLoaded", () => {
    fetchProducts();
  
    document.getElementById("addProductForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      await addProduct();
    });
  
    document.getElementById("cancelProductBtn").addEventListener("click", () => {
      document.getElementById("addProductModal").style.display = "none";
    });
  
    document.getElementById("addProductBtn").addEventListener("click", () => {
      document.getElementById("addProductModal").style.display = "flex";
    });
  });
  
  async function fetchProducts() {
    try {
      const res = await fetch("/api/products");
      const products = await res.json();
      const tableBody = document.getElementById("productsTableBody");
      tableBody.innerHTML = "";
  
      products.forEach(product => {
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${product.product_code}</td>
          <td>${product.name}</td>
          <td>${product.description || "—"}</td>
          <td>$${parseFloat(product.price).toFixed(2)}</td>
          <td>${product.stock_quantity}</td>
          <td>${product.category}</td>
          <td>${new Date(product.created_at).toLocaleDateString()}</td>
          <td>${new Date(product.updated_at).toLocaleDateString()}</td>
          <td class="action-buttons">
            <button class="action-btn view-btn" onclick='viewProduct(${JSON.stringify(product)})'>View</button>
            <button class="action-btn edit-btn" onclick='editProduct(${JSON.stringify(product)})'>Edit</button>
            <button class="action-btn delete-btn" onclick='deleteProduct(${product.product_id})'>Delete</button>
          </td>
        `;
        tableBody.appendChild(row);
      });
    } catch (err) {
      console.error("Failed to fetch products:", err);
    }
  }
  
  async function addProduct() {
    const product = {
      product_code: document.getElementById("productCode").value,
      name: document.getElementById("productName").value,
      description: document.getElementById("productDescription").value,
      price: parseFloat(document.getElementById("productPrice").value),
      stock_quantity: parseInt(document.getElementById("productStock").value),
      category: document.getElementById("productCategory").value
    };
  
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(product)
      });
  
      if (!res.ok) throw new Error("Failed to add product");
      Swal.fire('Success!', 'Order added successfully.', 'success');
      document.getElementById("addProductModal").style.display = "none";
      document.getElementById("addProductForm").reset();
      fetchProducts();
    } catch (err) {
      alert(err.message);
    }
  }
  
  function viewProduct(product) {
    Swal.fire({
      title: product.name,
      html: `
        <p><strong>SKU:</strong> ${product.product_code}</p>
        <p><strong>Category:</strong> ${product.category}</p>
        <p><strong>Price:</strong> $${parseFloat(product.price).toFixed(2)}</p>
        <p><strong>Stock:</strong> ${product.stock_quantity}</p>
        <p><strong>Description:</strong> ${product.description || "—"}</p>
      `,
      icon: "info",
      confirmButtonColor: "#10b981"
    });
  }
  
  function editProduct(product) {
    Swal.fire({
      title: 'Edit Product',
      html: `
        <input id="swalCode" class="swal2-input" placeholder="Product Code" value="${product.product_code}">
        <input id="swalName" class="swal2-input" placeholder="Name" value="${product.name}">
        <input id="swalCategory" class="swal2-input" placeholder="Category" value="${product.category}">
        <input id="swalPrice" class="swal2-input" type="number" step="0.01" placeholder="Price" value="${product.price}">
        <input id="swalStock" class="swal2-input" type="number" placeholder="Stock" value="${product.stock_quantity}">
        <textarea id="swalDesc" class="swal2-textarea" placeholder="Description">${product.description || ""}</textarea>
      `,
      showCancelButton: true,
      confirmButtonText: 'Update',
      preConfirm: () => {
        return {
          product_code: document.getElementById('swalCode').value,
          name: document.getElementById('swalName').value,
          category: document.getElementById('swalCategory').value,
          price: parseFloat(document.getElementById('swalPrice').value),
          stock_quantity: parseInt(document.getElementById('swalStock').value),
          description: document.getElementById('swalDesc').value
        };
      }
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          const res = await fetch(`/api/products/${product.product_id}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(result.value)
          });
          if (!res.ok) throw new Error("Update failed");
          Swal.fire("Success", "Product updated successfully", "success");
          fetchProducts();
        } catch (err) {
          Swal.fire("Error", err.message, "error");
        }
      }
    });
  }
  
  function deleteProduct(id) {
    Swal.fire({
      title: "Are you sure?",
      text: "This product will be permanently deleted.",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#ef4444",
      cancelButtonColor: "#6b7280",
      confirmButtonText: "Yes, delete it!"
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
          if (!res.ok) throw new Error("Delete failed");
          Swal.fire("Deleted!", "Product has been deleted.", "success");
          fetchProducts();
        } catch (err) {
          Swal.fire("Error", err.message, "error");
        }
      }
    });
  }
    