const fs = require('fs');
const path = require('path');

// Define source and destination
const sourcePath = path.join(__dirname, '../../node_modules/@ericblade/quagga2/dist/quagga.min.js');
const destDir = path.join(__dirname, '../vendor/quagga2');
const destPath = path.join(destDir, 'quagga.min.js');

// Ensure destination exists
if (!fs.existsSync(destDir)) {
  fs.mkdirSync(destDir, { recursive: true });
}

// Copy file
fs.copyFileSync(sourcePath, destPath);
console.log(`✅ Quagga2 copied to ${destPath}`);