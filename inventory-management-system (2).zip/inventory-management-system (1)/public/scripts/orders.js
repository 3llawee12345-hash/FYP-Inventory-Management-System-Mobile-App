// scripts/orders.js

// orders.js (Enhanced for Orders Page)

const addOrderBtn = document.getElementById('addOrderBtn');
const addOrderModal = document.getElementById('addOrderModal');
const cancelOrderBtn = document.getElementById('cancelOrderBtn');
const addOrderForm = document.getElementById('addOrderForm');
const ordersTableBody = document.getElementById('ordersTableBody');

addOrderBtn.addEventListener('click', () => {
  addOrderModal.style.display = 'flex';
});

cancelOrderBtn.addEventListener('click', () => {
  addOrderModal.style.display = 'none';
  addOrderForm.reset();
});

async function fetchOrders() {
  try {
    const res = await fetch('/api/orders');
    if (!res.ok) throw new Error('Failed to load');
    const data = await res.json();
    ordersTableBody.innerHTML = '';
    data.forEach(order => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${order.order_id}</td>
        <td>${order.customer_id}</td>
        <td><span class="status-badge ${order.order_status.toLowerCase()}">${order.order_status}</span></td>
        <td>${new Date(order.order_date).toLocaleDateString('en-CA').split('T')[0]}</td>
        <td>$${parseFloat(order.total_amount).toFixed(2)}</td>
        <td>
          <button class="btn btn-outline view-btn" data-id="${order.order_id}">View</button>
          <button class="btn btn-primary edit-btn" data-id="${order.order_id}">Edit</button>
          <button class="btn btn-outline delete-btn" data-id="${order.order_id}" style="background: #ef4444; color: white;">Delete</button>
        </td>
      `;
      ordersTableBody.appendChild(row);
    });
    attachOrderButtons();
  } catch (error) {
    console.error('Error loading orders:', error);
    alert('Error loading orders.');
  }
}

addOrderForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const newOrder = {
    customer_id: parseInt(document.getElementById('customerId').value),
    order_status: document.getElementById('orderStatus').value,
    order_date: document.getElementById('orderDate').value,
    total_amount: parseFloat(document.getElementById('totalAmount').value)
  };
  try {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newOrder)
    });
    if (res.ok) {
      Swal.fire('Success!', 'Order added successfully.', 'success');
      addOrderForm.reset();
      addOrderModal.style.display = 'none';
      fetchOrders();
    } else {
      Swal.fire('Error', 'Failed to add order.', 'error');
    }
  } catch (error) {
    console.error('Error adding order:', error);
    Swal.fire('Error', 'Server error.', 'error');
  }
});

function attachOrderButtons() {
  document.querySelectorAll('.view-btn').forEach(btn => btn.addEventListener('click', handleOrderView));
  document.querySelectorAll('.edit-btn').forEach(btn => btn.addEventListener('click', handleOrderEdit));
  document.querySelectorAll('.delete-btn').forEach(btn => btn.addEventListener('click', handleOrderDelete));
}

async function handleOrderView(event) {
  const id = event.target.dataset.id;
  try {
    const res = await fetch(`/api/orders/${id}`);
    const order = await res.json();
    Swal.fire({
      title: `Order #${order.order_id}`,
      html: `
        <b>Customer ID:</b> ${order.customer_id}<br>
        <b>Status:</b> ${order.order_status}<br>
        <b>Date:</b> ${order.order_date}<br>
        <b>Total:</b> $${order.total_amount}
      `,
      icon: 'info'
    });
  } catch (error) {
    console.error('View error:', error);
    Swal.fire('Error', 'Failed to load order.', 'error');
  }
}

async function handleOrderEdit(event) {
  const id = event.target.dataset.id;
  try {
    const res = await fetch(`/api/orders/${id}`);
    const order = await res.json();

    const { value: updated } = await Swal.fire({
      title: 'Edit Order',
      html: `
        <input id="swal-input1" class="swal2-input" value="${order.customer_id}" placeholder="Customer ID">
        <select id="swal-input2" class="swal2-input">
          <option value="Processing" ${order.status === 'Processing' ? 'selected' : ''}>Processing</option>
          <option value="Shipped" ${order.status === 'Shipped' ? 'selected' : ''}>Shipped</option>
          <option value="Delivered" ${order.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
          <option value="Cancelled" ${order.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
        </select>
        <input id="swal-input3" class="swal2-input" type="date" value="${order.order_date}">
        <input id="swal-input4" class="swal2-input" type="number" value="${order.total_amount}" placeholder="Total">`,
      focusConfirm: false,
      preConfirm: () => {
        return {
          customer_id: parseInt(document.getElementById('swal-input1').value),
          order_status: document.getElementById('swal-input2').value,
          order_date: document.getElementById('swal-input3').value,
          total_amount: parseFloat(document.getElementById('swal-input4').value)
        };
      }
    });

    if (updated) {
      await fetch(`/api/orders/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated)
      });
      Swal.fire('Updated!', 'Order updated successfully.', 'success');
      fetchOrders();
    }
  } catch (error) {
    console.error('Edit error:', error);
    Swal.fire('Error', 'Failed to edit order.', 'error');
  }
}

async function handleOrderDelete(event) {
  const id = event.target.dataset.id;
  Swal.fire({
    title: 'Are you sure?',
    text: 'This order will be permanently deleted!',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#10b981',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, delete it!'
  }).then(async (result) => {
    if (result.isConfirmed) {
      try {
        await fetch(`/api/orders/${id}`, { method: 'DELETE' });
        Swal.fire('Deleted!', 'Order has been deleted.', 'success');
        fetchOrders();
      } catch (error) {
        console.error('Delete error:', error);
        Swal.fire('Error', 'Failed to delete order.', 'error');
      }
    }
  });
}

document.addEventListener('DOMContentLoaded', fetchOrders);
