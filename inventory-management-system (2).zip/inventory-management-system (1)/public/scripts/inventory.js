// scripts/inventory.js 

// Selectors
const addItemBtn = document.getElementById('addItemBtn');
const addItemModal = document.getElementById('addItemModal');
const cancelBtn = document.getElementById('cancelBtn');
const addItemForm = document.getElementById('addItemForm');
const inventoryTableBody = document.getElementById('inventoryTableBody');

// Open Add Modal
addItemBtn.addEventListener('click', () => {
  addItemModal.style.display = 'flex';
});

// Close Modal
cancelBtn.addEventListener('click', () => {
  addItemModal.style.display = 'none';
});

// Fetch and Display Inventory
async function fetchInventory() {
  try {
    const res = await fetch('/api/inventory');
    if (!res.ok) throw new Error('Failed to load');
    const data = await res.json();

    inventoryTableBody.innerHTML = '';

    data.forEach(item => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${item.name}</td>
        <td>${item.sku}</td>
        <td>${item.location}</td>
        <td>${item.quantity}</td>
        <td><span class="inventory-status ${item.status.toLowerCase().replace(' ', '-')}">${item.status}</span></td>
        <td>
          <button class="btn btn-outline view-btn" data-id="${item.id}">View</button>
          <button class="btn btn-primary edit-btn" data-id="${item.id}">Edit</button>
          <button class="btn btn-outline delete-btn" data-id="${item.id}" style="background: #ef4444; color: white;">Delete</button>
        </td>
      `;
      inventoryTableBody.appendChild(row);
    });

    attachActionButtons();
  } catch (error) {
    console.error('Error loading inventory:', error);
    alert('Error loading inventory.');
  }
}

// Handle Add Item
addItemForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const newItem = {
    name: document.getElementById('itemName').value,
    sku: document.getElementById('itemSKU').value,
    location: document.getElementById('itemLocation').value,
    quantity: parseInt(document.getElementById('itemQuantity').value),
    status: document.getElementById('itemStatus').value
  };

  try {
    const res = await fetch('/api/inventory', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newItem)
    });

    if (res.ok) {
      Swal.fire('Success!', 'Item added successfully.', 'success');
      addItemForm.reset();
      addItemModal.style.display = 'none';
      fetchInventory();
    } else {
      Swal.fire('Error', 'Failed to add item.', 'error');
    }
  } catch (error) {
    console.error('Error adding item:', error);
    Swal.fire('Error', 'Server error.', 'error');
  }
});

// Attach Action Buttons
function attachActionButtons() {
  document.querySelectorAll('.view-btn').forEach(button => {
    button.addEventListener('click', handleView);
  });

  document.querySelectorAll('.edit-btn').forEach(button => {
    button.addEventListener('click', handleEdit);
  });

  document.querySelectorAll('.delete-btn').forEach(button => {
    button.addEventListener('click', handleDelete);
  });
}

// View Item Details
async function handleView(event) {
    const id = event.target.dataset.id;
    try {
      const res = await fetch('/api/inventory');
      const items = await res.json();
      const item = items.find(i => i.id == id);
  
      if (item) {
        Swal.fire({
          title: item.name,
          html: `
            <b>SKU:</b> ${item.sku}<br>
            <b>Location:</b> ${item.location}<br>
            <b>Quantity:</b> ${item.quantity}<br>
            <b>Status:</b> ${item.status}
          `,
          icon: 'info'
        });
      } else {
        Swal.fire('Error', 'Item not found.', 'error');
      }
    } catch (error) {
      console.error('Error viewing item:', error);
    }
  }
  
  // Edit Item
async function handleEdit(event) {
  const id = event.target.dataset.id;
  try {
    const res = await fetch('/api/inventory');
    const items = await res.json();
    const item = items.find(i => i.id == id);

    if (!item) {
      Swal.fire('Error', 'Item not found.', 'error');
      return;
    }

    const { value: formValues } = await Swal.fire({
      title: 'Edit Item',
      html: `
  <style>
    .swal2-html-container {
      padding: 0;
    }
    .swal-form-group {
      display: flex;
      flex-direction: column;
      gap: 1rem;
      margin-top: 1rem;
    }
    .swal-label {
      font-size: 0.9rem;
      font-weight: 600;
      color: #d1d5db;
      margin-bottom: 0.25rem;
    }
    .swal-input-wrapper {
      position: relative;
    }
    .swal-input-wrapper i {
      position: absolute;
      top: 50%;
      left: 0.75rem;
      transform: translateY(-50%);
      color: #9ca3af;
    }
    .swal2-input, .swal2-select {
      width: 100%;
      padding: 0.75rem 0.75rem 0.75rem 2.5rem;
      border-radius: 8px;
      background: #1f2937;
      border: 1px solid #374151;
      color: #f9fafb;
      font-size: 0.95rem;
    }
    .swal2-select {
      padding-left: 2.5rem;
    }
    .swal-input-row {
      display: flex;
      gap: 1rem;
    }
    .swal-input-row .swal-input-wrapper {
      flex: 1;
    }
  </style>
  <div class="swal-form-group">
    <div class="swal-input-wrapper">
      <label class="swal-label">Item Name</label>
      <i class="fas fa-box"></i>
      <input id="swal-input1" class="swal2-input" value="${item.name}">
    </div>
    <div class="swal-input-wrapper">
      <label class="swal-label">SKU</label>
      <i class="fas fa-barcode"></i>
      <input id="swal-input2" class="swal2-input" value="${item.sku}">
    </div>
    <div class="swal-input-wrapper">
      <label class="swal-label">Location</label>
      <i class="fas fa-map-marker-alt"></i>
      <input id="swal-input3" class="swal2-input" value="${item.location}">
    </div>
    <div class="swal-input-row">
      <div class="swal-input-wrapper">
        <label class="swal-label">Quantity</label>
        <i class="fas fa-boxes"></i>
        <input id="swal-input4" class="swal2-input" type="number" value="${item.quantity}">
      </div>
      <div class="swal-input-wrapper">
        <label class="swal-label">Status</label>
        <i class="fas fa-info-circle"></i>
        <select id="swal-input5" class="swal2-select">
          <option value="In Stock" ${item.status === 'In Stock' ? 'selected' : ''}>In Stock</option>
          <option value="Low Stock" ${item.status === 'Low Stock' ? 'selected' : ''}>Low Stock</option>
          <option value="Out of Stock" ${item.status === 'Out of Stock' ? 'selected' : ''}>Out of Stock</option>
        </select>
      </div>
    </div>
  </div>`,
      focusConfirm: false,
      preConfirm: () => {
        return {
          name: document.getElementById('swal-input1').value,
          sku: document.getElementById('swal-input2').value,
          location: document.getElementById('swal-input3').value,
          quantity: parseInt(document.getElementById('swal-input4').value),
          status: document.getElementById('swal-input5').value
        };
      }
    });

    if (formValues) {
      await fetch(`/api/inventory/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formValues)
      });
      Swal.fire('Updated!', 'Item updated successfully.', 'success');
      fetchInventory();
    }
  } catch (error) {
    console.error('Error editing item:', error);
    Swal.fire('Error', 'Failed to edit item.', 'error');
  }
}

  
  // Delete Item
  async function handleDelete(event) {
    const id = event.target.dataset.id;
    Swal.fire({
      title: 'Are you sure?',
      text: 'This item will be permanently deleted!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#10b981',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          await fetch(`/api/inventory/${id}`, { method: 'DELETE' });
          Swal.fire('Deleted!', 'Item has been deleted.', 'success');
          fetchInventory();
        } catch (error) {
          console.error('Error deleting item:', error);
        }
      }
    });
  }

  
  
  // Load Inventory on Page Load
  document.addEventListener('DOMContentLoaded', fetchInventory);