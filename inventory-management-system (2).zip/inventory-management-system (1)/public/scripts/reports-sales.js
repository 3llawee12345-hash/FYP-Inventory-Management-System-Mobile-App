document.addEventListener('DOMContentLoaded', () => {

  
    // ✅ Fetch and Populate Best-Selling Products Table
    fetch('/api/invoices/best-selling')
      .then(response => response.json())
      .then(products => {
        const tableBody = document.getElementById('bestSellingProductsTableBody');
        tableBody.innerHTML = '';
        products.forEach(item => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${item.product}</td>
            <td>${item.units_sold}</td>
            <td>$${(parseFloat(item.total_revenue) || 0).toFixed(2)}</td>
          `;
          tableBody.appendChild(row);
        });
  
        // ✅ Enable CSV Download with Live Data
        document.getElementById('downloadReportBtn').addEventListener('click', () => {
          let csvContent = 'Product,Units Sold,Total Revenue\n';
          products.forEach(item => {
            csvContent += `${item.product},${item.units_sold},${item.total_revenue}\n`;
          });
  
          const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
          const url = URL.createObjectURL(blob);
          const link = document.createElement('a');
          link.href = url;
          link.download = 'sales-report.csv';
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        });
  
      })
      .catch(err => {
        console.error('Failed to load best-selling products:', err);
      });
  
  });
  