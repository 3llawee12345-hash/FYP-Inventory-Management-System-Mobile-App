// ✅ Globally available utility functions
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
  }
  
  function openModal(modalId) {
    document.getElementById(modalId).style.display = 'block';
  }
  
  // ✅ Fetch and display all invoices - globally accessible
  async function fetchAndDisplayInvoices() {
    const invoiceTableSection = document.getElementById('invoiceTableSection');
    const invoiceTableBody = document.getElementById('invoicesTableBody');
  
    try {
      const response = await fetch('/api/invoices');
      if (!response.ok) {
        const errorText = await response.text();
        console.error('Server error:', errorText);
        throw new Error('Failed to fetch invoices');
      }
  
      const invoices = await response.json();
      invoiceTableBody.innerHTML = '';
  
      if (invoices.length === 0) {
        invoiceTableBody.innerHTML = '<tr><td colspan="7">No invoices available</td></tr>';
        return;
      }
  
      invoices.forEach(invoice => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${invoice.invoice_id}</td>
          <td>${invoice.order_id}</td>
          <td>${invoice.customer_id || 'N/A'}</td>
          <td>${invoice.total_amount}</td>
          <td>${new Date(invoice.issue_date).toLocaleDateString()}</td>
          <td>${invoice.status}</td>
          <td>
            <button class="btn btn-primary view-invoice-btn" data-id="${invoice.invoice_id}"><i class="fas fa-file-invoice"></i> View Invoice</button>
            <button class="btn btn-outline generate-invoice-btn" data-id="${invoice.order_id}"><i class="fas fa-plus-circle"></i> Generate Invoice</button>
            <button class="btn btn-outline edit-invoice-btn" data-id="${invoice.invoice_id}"><i class="fas fa-edit"></i> Edit Invoice</button>
          </td>
        `;
        invoiceTableBody.appendChild(row);
      });
  
    } catch (error) {
      console.error('Error loading invoices:', error);
      alert('Failed to load invoices. Please try again later.');
    }
  }
  
  // ✅ Open View Invoice Modal
  function openViewInvoiceModal(invoiceData) {
    const content = document.getElementById('viewInvoiceContent');
    content.innerHTML = `
      <p><strong>Invoice ID:</strong> ${invoiceData.invoiceId}</p>
      <p><strong>Order ID:</strong> ${invoiceData.orderId}</p>
      <p><strong>Customer ID:</strong> ${invoiceData.customerId}</p>
      <p><strong>Total Amount:</strong> ${invoiceData.amount}</p>
      <p><strong>Issue Date:</strong> ${invoiceData.issueDate}</p>
      <p><strong>Status:</strong> ${invoiceData.status}</p>
    `;
    openModal('viewInvoiceModal');
  }
  
  
  // ✅ Navigate to Generate Invoice Page
  function navigateToGenerateInvoice(orderId) {
    window.location.href = `/Pages/Dashboards/generate-invoice.html?orderId=${orderId}`;
  }
  
  // ✅ Open Edit Invoice Modal
  function openEditInvoiceModal(invoiceId) {
    const invoiceRow = document.querySelector(`button[data-id="${invoiceId}"]`).closest('tr');
    const columns = invoiceRow.querySelectorAll('td');
    const currentAmount = columns[3].textContent.trim();
    const currentStatus = columns[5].textContent.trim();
  
    const invoiceDetailsHTML = `
      <p>Edit Invoice ID: <strong>${columns[0].textContent}</strong></p>
      <label>Total Amount:</label>
      <input type="number" id="editTotalAmount" value="${currentAmount}" required>
      <label>Status:</label>
      <select id="editStatus" required>
        <option value="Pending"${currentStatus === 'Pending' ? ' selected' : ''}>Pending</option>
        <option value="Paid"${currentStatus === 'Paid' ? ' selected' : ''}>Paid</option>
        <option value="Cancelled"${currentStatus === 'Cancelled' ? ' selected' : ''}>Cancelled</option>
      </select>
      <button class="btn btn-primary" onclick="saveInvoiceEdits('${invoiceId}')">Save Changes</button>
    `;
  
    document.getElementById('viewInvoiceContent').innerHTML = invoiceDetailsHTML;
    openModal('viewInvoiceModal');
  }
  
  // ✅ Save Invoice Edits and Refresh Table
  async function saveInvoiceEdits(invoiceId) {
    const updatedAmount = document.getElementById('editTotalAmount').value;
    const updatedStatus = document.getElementById('editStatus').value;
  
    try {
      const response = await fetch(`/api/invoices/${invoiceId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ total_amount: updatedAmount, status: updatedStatus })
      });
  
      const result = await response.json();
      if (response.ok) {
        alert(result.message);
        closeModal('viewInvoiceModal');
        fetchAndDisplayInvoices();
      } else {
        alert('Error: ' + result.error);
      }
    } catch (error) {
      console.error('Error updating invoice:', error);
      alert('An unexpected error occurred while updating the invoice.');
    }
  }
  
  // ✅ Sync Orders to Invoices API Call
  async function syncOrdersToInvoices() {
    try {
      const response = await fetch('/api/invoices/sync-from-orders', { method: 'POST' });
      const result = await response.json();
      if (response.ok) {
        alert(`Sync Successful: ${result.affectedRows} invoices created.`);
        fetchAndDisplayInvoices();
      } else {
        alert('Sync Failed: ' + result.error);
      }
    } catch (error) {
      console.error('Sync Failed:', error);
    }
  }
  
  // ✅ Setup Event Listeners Once DOM is Ready
  document.addEventListener('DOMContentLoaded', () => {
    const invoiceTableBody = document.getElementById('invoicesTableBody');
    const viewInvoicesButton = document.getElementById('viewInvoicesBtn');
  
    if (viewInvoicesButton) {
      viewInvoicesButton.addEventListener('click', fetchAndDisplayInvoices);
    }
  
    invoiceTableBody.addEventListener('click', function (e) {
      const targetButton = e.target.closest('button');
      if (!targetButton) return;
  
      const invoiceRow = targetButton.closest('tr');
      if (!invoiceRow) {
        console.error('No row found.');
        return;
      }
  
      const columns = invoiceRow.querySelectorAll('td');
      if (columns.length < 6) {
        console.error('Incomplete row data.');
        return;
      }
  
      const invoiceData = {
        invoiceId: columns[0].textContent.trim(),
        orderId: columns[1].textContent.trim(),
        customerId: columns[2].textContent.trim(),
        amount: columns[3].textContent.trim(),
        issueDate: columns[4].textContent.trim(),
        status: columns[5].textContent.trim()
      };
  
      if (targetButton.classList.contains('view-invoice-btn')) {
        openViewInvoiceModal(invoiceData);
      } else if (targetButton.classList.contains('generate-invoice-btn')) {
        showInvoicePreview(invoiceData);
      } else if (targetButton.classList.contains('edit-invoice-btn')) {
        openEditInvoiceModal(invoiceData.invoiceId);
      }
    });
  
    // ✅ Modal Population Function
    function openViewInvoiceModal(invoiceData) {
      const content = document.getElementById('viewInvoiceContent');
      content.innerHTML = `
        <p><strong>Invoice ID:</strong> ${invoiceData.invoiceId}</p>
        <p><strong>Order ID:</strong> ${invoiceData.orderId}</p>
        <p><strong>Customer ID:</strong> ${invoiceData.customerId}</p>
        <p><strong>Total Amount:</strong> ${invoiceData.amount}</p>
        <p><strong>Issue Date:</strong> ${invoiceData.issueDate}</p>
        <p><strong>Status:</strong> ${invoiceData.status}</p>
      `;
      openModal('viewInvoiceModal');
    }
  
    // ✅ Print Preview Function with Tax Calculation
    function showInvoicePreview({ invoiceId, orderId, customerId, amount, status }) {
      const taxRate = 0.10;
      const subtotal = parseFloat(amount);
      const tax = subtotal * taxRate;
      const total = subtotal + tax;
  
      const printWindow = window.open('', '_blank');
      printWindow.document.write(`
        <html>
        <head>
          <title>Invoice #${invoiceId}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 40px; background: #f9f9f9; }
            .invoice-box { max-width: 800px; margin: auto; padding: 30px; border: 1px solid #eee; box-shadow: 0 0 10px rgba(0, 0, 0, 0.15); background: #fff; }
            .invoice-header { text-align: center; border-bottom: 2px solid #000; margin-bottom: 20px; }
            .invoice-header img { width: 100px; margin-bottom: 10px; }
            .invoice-header h1 { margin: 0; font-size: 24px; }
            .invoice-details, .invoice-summary { margin-top: 20px; }
            .invoice-details p, .invoice-summary p { margin: 5px 0; }
            .print-button { margin-top: 20px; padding: 10px 20px; background: #00c896; color: #fff; border: none; cursor: pointer; }
          </style>
        </head>
        <body>
          <div class="invoice-box">
            <div class="invoice-header">
              <img src="/images/logo.png" alt="Company Logo">
              <h1>InventoryPro Solutions</h1>
              <p>Invoice #${invoiceId}</p>
            </div>
  
            <div class="invoice-details">
              <p><strong>Order ID:</strong> ${orderId}</p>
              <p><strong>Customer ID:</strong> ${customerId}</p>
              <p><strong>Status:</strong> ${status}</p>
              <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
            </div>
  
            <div class="invoice-summary">
              <p><strong>Subtotal:</strong> $${subtotal.toFixed(2)}</p>
              <p><strong>Tax (10%):</strong> $${tax.toFixed(2)}</p>
              <p><strong>Total Amount:</strong> $${total.toFixed(2)}</p>
            </div>
  
            <button class="print-button" onclick="window.print()">Print Invoice</button>
          </div>
        </body>
        </html>
      `);
      printWindow.document.close();
    }
  
    // ✅ Initial Load of Invoices Table
    fetchAndDisplayInvoices();
  });
  