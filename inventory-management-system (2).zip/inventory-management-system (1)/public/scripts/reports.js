document.addEventListener("DOMContentLoaded", () => {
    fetchSalesByCategory();
    fetchInventoryDistribution();
  });
  
  async function fetchSalesByCategory() {
    try {
      const res = await fetch("/api/reports/sales-by-category");
      const data = await res.json();
  
      if (!Array.isArray(data)) {
        console.warn("Expected array, received:", data);
        return renderSalesChart([], []); // render empty chart gracefully
      }
  
      const labels = data.map(item => item.category || "Unknown");
      const values = data.map(item => parseFloat(item.total_sales) || 0);
  
      renderSalesChart(labels, values);
    } catch (err) {
      console.error("Error fetching sales data:", err);
      renderSalesChart([], []); // optional fallback
    }
  }
  
  
  
  async function fetchInventoryDistribution() {
    try {
      const res = await fetch("/api/reports/inventory-distribution");
      const data = await res.json();
  
      const labels = data.map(item => item.status);
      const values = data.map(item => item.count);
  
      renderInventoryChart(labels, values);
    } catch (err) {
      console.error("Error fetching inventory data:", err);
    }
  }
  
  function renderSalesChart(labels, values) {
    const ctx = document.getElementById("salesChart").getContext("2d");
    new Chart(ctx, {
      type: "bar",
      data: {
        labels: labels,
        datasets: [{
          label: "Sales ($)",
          data: values,
          backgroundColor: "#10b981"
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { display: false },
          title: {
            display: true,
            text: "Total Sales by Category"
          }
        }
      }
    });
  }
  
  function renderInventoryChart(labels, values) {
    const ctx = document.getElementById("inventoryChart").getContext("2d");
    new Chart(ctx, {
      type: "pie",
      data: {
        labels: labels,
        datasets: [{
          label: "Inventory Status",
          data: values,
          backgroundColor: ["#10b981", "#facc15", "#ef4444"]
        }]
      },
      options: {
        responsive: true,
        plugins: {
          title: {
            display: true,
            text: "Inventory Stock Distribution"
          }
        }
      }
    });
  }
  