// scripts/customers.js

const addCustomerBtn = document.getElementById('addCustomerBtn');
const addCustomerModal = document.getElementById('addCustomerModal');
const cancelCustomerBtn = document.getElementById('cancelCustomerBtn');
const addCustomerForm = document.getElementById('addCustomerForm');
const customersTableBody = document.getElementById('customersTableBody');

// Open modal
addCustomerBtn.addEventListener('click', () => {
  addCustomerModal.style.display = 'flex';
});

// Close modal
cancelCustomerBtn.addEventListener('click', () => {
  addCustomerModal.style.display = 'none';
});

// Fetch and render customers
async function fetchCustomers() {
  try {
    const response = await fetch('/api/customers');
    if (!response.ok) throw new Error('Failed to fetch customers');
    const customers = await response.json();

    customersTableBody.innerHTML = '';
    customers.forEach(customer => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${customer.full_name}</td>
        <td>${customer.email}</td>
        <td>${customer.phone}</td>
        <td>${customer.address}</td>
        <td>${new Date(customer.created_at).toLocaleDateString()}</td>
        <td>${new Date(customer.updated_at).toLocaleDateString()}</td>
        <td>
  <div class="action-buttons">
    <button class="action-btn view-btn">View</button>
    <button class="action-btn edit-btn">Edit</button>
    <button class="action-btn delete-btn" onclick="deleteCustomer(${customer.customer_id})">Delete</button>
  </div>
</td>`;
// Add event listeners
row.querySelector('.view-btn').addEventListener('click', () => handleViewCustomer(customer));
row.querySelector('.edit-btn').addEventListener('click', () => handleEditCustomer(customer));

      customersTableBody.appendChild(row);
    });
  } catch (err) {
    alert(`Error loading customers: ${err.message}`);
  }
}

// Add new customer
addCustomerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = {
    full_name: document.getElementById('customerName').value,
    email: document.getElementById('customerEmail').value,
    phone: document.getElementById('customerPhone').value,
    address: document.getElementById('customerAddress').value
  };

  try {
    const response = await fetch('/api/customers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });

    if (!response.ok) throw new Error('Failed to add customer');
    alert('Customer added successfully!');
    addCustomerForm.reset();
    addCustomerModal.style.display = 'none';
    fetchCustomers();
  } catch (err) {
    alert(`Error adding customer: ${err.message}`);
  }
});

// Delete customer
function deleteCustomer(id) {
    Swal.fire({
      title: 'Are you sure?',
      text: 'This will permanently delete the customer.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '##10b981',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then(async (result) => {
      if (result.isConfirmed) {
        try {
          const res = await fetch(`/api/customers/${id}`, { method: 'DELETE' });
          if (!res.ok) throw new Error('Delete failed');
          Swal.fire('Deleted!', 'Customer has been deleted.', 'success');
          fetchCustomers();
        } catch (err) {
          Swal.fire('Error', err.message, 'error');
        }
      }
    });
  }
  
// View button handler (just for demo — you can enhance it)
function handleViewCustomer(customer) {
    Swal.fire({
      title: customer.full_name,
      html: `
        <p><strong>Email:</strong> ${customer.email || '—'}</p>
        <p><strong>Phone:</strong> ${customer.phone || '—'}</p>
        <p><strong>Address:</strong> ${customer.address || '—'}</p>
        <p><strong>Created At:</strong> ${new Date(customer.created_at).toLocaleString()}</p>
        <p><strong>Updated At:</strong> ${new Date(customer.updated_at).toLocaleString()}</p>
      `,
      icon: 'info',
      confirmButtonText: 'OK',
      confirmButtonColor: '#10b981',
      customClass: {
        popup: 'swal2-dark',
      }
    });
  }
  
  
  // Show edit modal with data
  function handleEditCustomer(customer) {
    Swal.fire({
      title: 'Edit Customer',
      html: `
        <input id="swalCustomerName" class="swal2-input" placeholder="Full Name" value="${customer.full_name}">
        <input id="swalCustomerEmail" class="swal2-input" placeholder="Email" value="${customer.email}">
        <input id="swalCustomerPhone" class="swal2-input" placeholder="Phone" value="${customer.phone}">
        <textarea id="swalCustomerAddress" class="swal2-textarea" placeholder="Address">${customer.address}</textarea>
      `,
      focusConfirm: false,
      showCancelButton: true,
      confirmButtonText: 'Update',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#10b981',
      cancelButtonColor: '#6b7280',
      preConfirm: () => {
        const full_name = document.getElementById('swalCustomerName').value.trim();
        const email = document.getElementById('swalCustomerEmail').value.trim();
        const phone = document.getElementById('swalCustomerPhone').value.trim();
        const address = document.getElementById('swalCustomerAddress').value.trim();
  
        if (!full_name) {
          Swal.showValidationMessage('Full name is required');
          return false;
        }
  
        return { full_name, email, phone, address };
      }
    }).then(async (result) => {
      if (result.isConfirmed && result.value) {
        try {
          const response = await fetch(`/api/customers/${customer.customer_id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(result.value)
          });
          if (!response.ok) throw new Error('Update failed');
          Swal.fire('Success', 'Customer updated successfully', 'success');
          fetchCustomers();
        } catch (err) {
          Swal.fire('Error', err.message, 'error');
        }
      }
    });
  }
  
  
  // Cancel button
  document.getElementById('cancelEditBtn').addEventListener('click', () => {
    document.getElementById('editCustomerModal').style.display = 'none';
  });
  
  // Submit edit form
  document.getElementById('editCustomerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('editCustomerId').value;
    const updatedCustomer = {
      full_name: document.getElementById('editCustomerName').value,
      email: document.getElementById('editCustomerEmail').value,
      phone: document.getElementById('editCustomerPhone').value,
      address: document.getElementById('editCustomerAddress').value
    };
  
    try {
      const response = await fetch(`/api/customers/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedCustomer)
      });
      if (!response.ok) throw new Error('Update failed');
      alert('✅ Customer updated successfully!');
      document.getElementById('editCustomerModal').style.display = 'none';
      fetchCustomers();
    } catch (err) {
      alert(`❌ Error updating customer: ${err.message}`);
    }
  });
  

// Initial load
document.addEventListener('DOMContentLoaded', fetchCustomers);
