// routes/orders.js
// routes/orders.js
const express = require('express');
const router = express.Router();
const db = require('../config/db'); // ✅ Database connection

// GET all orders
router.get('/orders', (req, res) => {
  db.query('SELECT * FROM orders', (err, results) => {
    if (err) {
      console.error('Error fetching orders:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json(results);
  });
});

// GET one order by ID
router.get('/orders/:id', (req, res) => {
  const { id } = req.params;
  db.query('SELECT * FROM orders WHERE order_id = ?', [parseInt(id)], (err, results) => {
    if (err) {
      console.error('Error fetching order:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Order not found' });
    }
    res.json(results[0]);
  });
});



// POST (Add) new order
// routes/orders.js (Example)
router.post('/orders', (req, res) => {
  const { customer_id, order_status, order_date, total_amount } = req.body;

  const orderSql = `
    INSERT INTO orders (customer_id, order_status, order_date, total_amount)
    VALUES (?, ?, ?, ?)
  `;

  db.query(orderSql, [customer_id, order_status, order_date, total_amount], (err, orderResult) => {
    if (err) {
      console.error('Error adding order:', err);
      return res.status(500).json({ error: 'Error adding order' });
    }

    const newOrderId = orderResult.insertId;

    const invoiceSql = `
      INSERT INTO invoices (order_id, customer_id, total_amount, status, issue_date, created_at)
      VALUES (?, ?, ?, '', CURDATE(), NOW())
    `;

    db.query(invoiceSql, [newOrderId, customer_id, total_amount], (invoiceErr) => {
      if (invoiceErr) {
        console.error('Error creating invoice:', invoiceErr);
        return res.status(500).json({ error: 'Order created but failed to generate invoice' });
      }

      res.status(201).json({ message: 'Order and invoice created successfully', orderId: newOrderId });
    });
  });
});

  

// PUT (Update) an order
router.put('/orders/:id', (req, res) => {
  const { id } = req.params;
  const { customer_id, order_status, order_date, total_amount } = req.body;
  const sql = 'UPDATE orders SET customer_id = ?, order_status = ?, order_date = ?, total_amount = ? WHERE order_id = ?';
  db.query(sql, [customer_id, order_status, order_date, total_amount, parseInt(id)], (err, result) => {
    if (err) {
      console.error('Error updating order:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json({ message: 'Order updated successfully' });
  });
});

// DELETE an order
router.delete('/orders/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM orders WHERE order_id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('Error deleting order:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json({ message: 'Order deleted successfully' });
  });
});

module.exports = router;
