// routes/products.js

const express = require("express");
const router = express.Router();
const db = require("../config/db"); // MySQL connection
const { body, validationResult } = require("express-validator");

// GET all products
router.get("/products", (req, res) => {
  db.query("SELECT * FROM products", (err, rows) => {
    if (err) return res.status(500).json({ message: "Failed to retrieve products" });
    res.json(rows);
  });
});

// POST create new product
router.post(
  "/products",
  [
    body("product_code").notEmpty(),
    body("name").notEmpty(),
    body("price").isFloat({ gt: 0 }),
    body("stock_quantity").isInt({ min: 0 }),
    body("category").notEmpty()
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { product_code, name, description, price, stock_quantity, category } = req.body;

    db.query(
      `INSERT INTO products (product_code, name, description, price, stock_quantity, category) VALUES (?, ?, ?, ?, ?, ?)`,
      [product_code, name, description, price, stock_quantity, category],
      (err, result) => {
        if (err) return res.status(500).json({ message: "Failed to add product" });
        res.status(201).json({ id: result.insertId });
      }
    );
  }
);

// PUT update product
router.put(
  "/products/:id",
  [
    body("product_code").notEmpty(),
    body("name").notEmpty(),
    body("price").isFloat({ gt: 0 }),
    body("stock_quantity").isInt({ min: 0 }),
    body("category").notEmpty()
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { id } = req.params;
    const { product_code, name, description, price, stock_quantity, category } = req.body;

    db.query(
      `UPDATE products SET product_code=?, name=?, description=?, price=?, stock_quantity=?, category=? WHERE product_id=?`,
      [product_code, name, description, price, stock_quantity, category, id],
      (err) => {
        if (err) return res.status(500).json({ message: "Failed to update product" });
        res.status(200).json({ message: "Product updated" });
      }
    );
  }
);

// DELETE product
router.delete("/products/:id", (req, res) => {
  const { id } = req.params;
  db.query("DELETE FROM products WHERE product_id = ?", [id], (err) => {
    if (err) return res.status(500).json({ message: "Failed to delete product" });
    res.status(200).json({ message: "Product deleted" });
  });
});

module.exports = router;
