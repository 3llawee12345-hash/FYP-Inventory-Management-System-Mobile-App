// routes/invoices.js
const express = require('express');
const router = express.Router();
const db = require('../config/db'); // Adjust path if necessary

/**
 * @route   GET /api/invoices
 * @desc    Fetch all invoices with linked order information
 */
router.get('/invoices', (req, res) => {
  const sql = `
    SELECT 
      invoices.invoice_id,
      invoices.order_id,
      orders.customer_id,
      invoices.total_amount,
      invoices.status,
      invoices.issue_date
    FROM invoices
    JOIN orders ON invoices.order_id = orders.order_id
    ORDER BY invoices.invoice_id DESC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Database query error:', err);
      return res.status(500).json({ error: 'Internal Server Error', details: err.message });
    }

    if (!results || results.length === 0) {
      return res.status(404).json({ error: 'No invoices found' });
    }

    res.status(200).json(results);
  });
});

router.post('/invoices/sync-from-orders', (req, res) => {
    const sql = `
      INSERT INTO invoices (order_id, customer_id, total_amount, status, issue_date, created_at)
      SELECT order_id, customer_id, total_amount, '', CURDATE(), NOW()
      FROM orders
    `;
  
    db.query(sql, (err, result) => {
      if (err) {
        console.error('Error syncing orders to invoices:', err);
        return res.status(500).json({ error: 'Database error', details: err.message });
      }
  
      res.status(201).json({ message: 'Orders synced to invoices successfully', affectedRows: result.affectedRows });
    });
  });

  /**
 * @route   PATCH /api/invoices/:invoiceId
 * @desc    Update total_amount and status of an invoice
 */
router.patch('/invoices/:invoiceId', (req, res) => {
    const invoiceId = req.params.invoiceId;
    const { total_amount, status } = req.body;
  
    if (!total_amount || !status) {
      return res.status(400).json({ error: 'Missing total_amount or status in request body' });
    }
  
    const sql = `
      UPDATE invoices
      SET total_amount = ?, status = ?
      WHERE invoice_id = ?
    `;
  
    db.query(sql, [total_amount, status, invoiceId], (err, result) => {
      if (err) {
        console.error('Error updating invoice:', err);
        return res.status(500).json({ error: 'Database error', details: err.message });
      }
  
      if (result.affectedRows === 0) {
        return res.status(404).json({ error: 'Invoice not found' });
      }
  
      res.status(200).json({ message: 'Invoice updated successfully' });
    });
  });



// ✅ Fetch Best-Selling Products (Example)
router.get('/invoices/best-selling', (req, res) => {
  const sql = `
    SELECT 
  p.name AS product,
  SUM(oi.quantity) AS units_sold,
  SUM(oi.quantity * oi.price) AS total_revenue
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
GROUP BY p.name
ORDER BY units_sold DESC
LIMIT 10
  `;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching best-selling products:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
});

  

module.exports = router;
