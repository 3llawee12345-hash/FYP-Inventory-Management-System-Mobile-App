const express = require('express');
const router = express.Router();
const db = require('../config/db');

// GET /api/dashboard/summary
router.get('/summary', (req, res) => {
  const summary = {
    products: 0,
    orders: 0,
    itemsInInventory: 0,
    incomingShipments: 0,
    outgoingShipments: 0
  };

  const queries = [
    // Total Products
    new Promise((resolve, reject) => {
      db.query('SELECT COUNT(*) AS total FROM products', (err, result) => {
        if (err) reject(err);
        else {
          summary.products = result[0].total;
          resolve();
        }
      });
    }),

    // Total Orders
    new Promise((resolve, reject) => {
      db.query('SELECT COUNT(*) AS total FROM orders', (err, result) => {
        if (err) reject(err);
        else {
          summary.orders = result[0].total;
          resolve();
        }
      });
    }),

    // Items in Inventory
    new Promise((resolve, reject) => {
      db.query('SELECT SUM(quantity) AS total FROM inventory', (err, result) => {
        if (err) reject(err);
        else {
          summary.itemsInInventory = result[0].total || 0;
          resolve();
        }
      });
    }),

    // Incoming Shipments
    new Promise((resolve, reject) => {
      db.query("SELECT COUNT(*) AS total FROM receipts WHERE status != 'Completed'", (err, result) => {
        if (err) reject(err);
        else {
          summary.incomingShipments = result[0].total || 0;
          resolve();
        }
      });
    }),

    // Outgoing Shipments
    new Promise((resolve, reject) => {
      db.query("SELECT COUNT(*) AS total FROM shipments WHERE status = 'Shipped'", (err, result) => {
        if (err) reject(err);
        else {
          summary.outgoingShipments = result[0].total || 0;
          resolve();
        }
      });
    })
  ];

  Promise.all(queries)
    .then(() => res.json(summary))
    .catch(err => {
      console.error('❌ Error fetching dashboard summary:', err);
      res.status(500).json({ error: 'Database error' });
    });
});

module.exports = router;
