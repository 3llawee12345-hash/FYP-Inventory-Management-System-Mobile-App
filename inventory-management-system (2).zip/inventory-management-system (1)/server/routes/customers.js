// server/routes/customers.js

const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Get all customers
router.get('/customers', (req, res) => {
  const query = 'SELECT * FROM customers ORDER BY created_at DESC';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error fetching customers:', err);
      return res.status(500).json({ error: 'Error fetching customers' });
    }
    res.json(results);
  });
});

// Add new customer
router.post('/customers', (req, res) => {
  const { full_name, email, phone, address } = req.body;
  const query = 'INSERT INTO customers (full_name, email, phone, address) VALUES (?, ?, ?, ?)';
  db.query(query, [full_name, email, phone, address], (err, result) => {
    if (err) {
      console.error('Error adding customer:', err);
      return res.status(500).json({ error: 'Error adding customer' });
    }
    res.json({ message: 'Customer added successfully', customerId: result.insertId });
  });
});

// Delete a customer
router.delete('/customers/:id', (req, res) => {
  const customerId = req.params.id;
  const query = 'DELETE FROM customers WHERE customer_id = ?';
  db.query(query, [customerId], (err, result) => {
    if (err) {
      console.error('Error deleting customer:', err);
      return res.status(500).json({ error: 'Error deleting customer' });
    }
    res.json({ message: 'Customer deleted successfully' });
  });
});

// Update a customer
router.put('/customers/:id', (req, res) => {
  const { id } = req.params;
  const { full_name, email, phone, address } = req.body;
  const query = 'UPDATE customers SET full_name = ?, email = ?, phone = ?, address = ?, updated_at = NOW() WHERE customer_id = ?';
  db.query(query, [full_name, email, phone, address, id], (err, result) => {
    if (err) {
      console.error('Error updating customer:', err);
      return res.status(500).json({ error: 'Error updating customer' });
    }
    res.json({ message: 'Customer updated successfully' });
  });
});

module.exports = router;
