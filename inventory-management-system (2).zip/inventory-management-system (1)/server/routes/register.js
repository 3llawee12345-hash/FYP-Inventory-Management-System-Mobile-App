const express = require('express');
const router = express.Router();
const mysql = require('mysql2');

// DB connection
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '', // your MySQL password
  database: 'inventory_system'
});

// POST /api/signup
router.post('/register', (req, res) => {
  const { name, email, password, role } = req.body;

  const lowercaseRole = role.toLowerCase();

  const checkQuery = 'SELECT * FROM users WHERE email = ?';
  db.query(checkQuery, [email], (err, results) => {
    if (results.length > 0) {
      return res.status(409).json({ message: 'User already exists' });
    }

    const insertQuery = 'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)';
    db.query(insertQuery, [name, email, password, role], (err, result) => {
      if (err) return res.status(500).json({ message: 'Error creating user' });
      res.status(200).json({ message: 'User created successfully' });
    });
  });
});

module.exports = router;
