// routes/inventory.js
const express = require('express');
const router = express.Router();
const db = require('../config/db'); // ✅ Important: database connection

// GET all inventory
router.get('/inventory', (req, res) => {
  db.query('SELECT * FROM inventory', (err, results) => {
    if (err) {
      console.error('Error fetching inventory:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json(results);
  });
});

// POST (Add) new inventory item
router.post('/inventory', (req, res) => {
  const { name, sku, location, quantity, status } = req.body;
  const sql = 'INSERT INTO inventory (name, sku, location, quantity, status) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [name, sku, location, quantity, status], (err, result) => {
    if (err) {
      console.error('Error adding item:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json({ id: result.insertId, name, sku, location, quantity, status });
  });
});

// PUT (Update) inventory item
router.put('/inventory/:id', (req, res) => {
  const { id } = req.params;
  const { name, sku, location, quantity, status } = req.body;
  const sql = 'UPDATE inventory SET name = ?, sku = ?, location = ?, quantity = ?, status = ? WHERE id = ?';
  db.query(sql, [name, sku, location, quantity, status, id], (err, result) => {
    if (err) {
      console.error('Error updating item:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json({ message: 'Item updated successfully' });
  });
});

// DELETE inventory item
router.delete('/inventory/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM inventory WHERE id = ?';
  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('Error deleting item:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json({ message: 'Item deleted successfully' });
  });
});

module.exports = router;
