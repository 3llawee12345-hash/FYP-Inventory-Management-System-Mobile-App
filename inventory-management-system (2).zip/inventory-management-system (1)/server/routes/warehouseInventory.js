const express = require('express');
const router = express.Router();
const db = require('../config/db');
const {authenticateToken} = require('../middleware/auth');

// 🔍 GET: Inventory Logs
router.get('/inventory/logs', (req, res) => {
  const sql = `
    SELECT log_id, product_id, change_type, quantity_changed, timestamp, user_id
    FROM inventory_log
    ORDER BY timestamp DESC
  `;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching inventory logs:', err);
      return res.status(500).json({ error: 'Server error' });
    }
    res.json(results);
  });
});

// 📦 GET: All Inventory Items
router.get('/inventory/items', (req, res) => {
  const sql = 'SELECT * FROM inventory';
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching inventory:', err);
      return res.status(500).json({ error: 'Failed to fetch inventory' });
    }
    res.json(results);
  });
});

// 📝 PUT: Edit or Adjust Inventory Item (with JWT Auth)
router.put('/inventory/items/:id', authenticateToken, (req, res) => {
  const { id } = req.params;
  const { name, sku, location, status, quantity } = req.body;
  const user_id = req.user?.id;
  console.log('🔐 User from JWT:', req.user);
  console.log('📥 Request Body:', req.body);

  // 🔁 Quantity Adjustment
  if (quantity != null && !name && !location && !status) {
    const updateSql = `UPDATE inventory SET quantity = ? WHERE id = ?`;
    db.query(updateSql, [quantity, id], (err) => {
      if (err) {
        console.error('❌ Error updating quantity:', err);
        return res.status(500).json({ error: 'Failed to update quantity' });
      }

      // Log the change
      console.log('📦 Logging adjustment with:', {
        product_id: id,
        quantity_changed: quantity,
        user_id: user_id
      });
      
      const logSql = `
      INSERT INTO inventory_log (product_id, change_type, quantity_changed, timestamp, user_id)
      VALUES (?, 'Adjusted', ?, NOW(), ?)
    `;    
      db.query(logSql, [id, quantity, user_id], (logErr) => {
        if (logErr) {
          console.error('❌ Error logging adjustment:', logErr);
          return res.status(500).json({ error: 'Quantity updated, but failed to log adjustment' });
        }

        return res.json({ message: 'Quantity adjusted and log recorded' });
      });
    });
  }

  // ✏️ Regular Edit (name, location, etc.)
  else if (name && location && status) {
    const sql = `UPDATE inventory SET name = ?, sku = ?, location = ?, status = ? WHERE id = ?`;
    db.query(sql, [name, sku, location, status, id], (err) => {
      if (err) {
        console.error('❌ Error updating item:', err);
        return res.status(500).json({ error: 'Failed to update item' });
      }
      res.json({ message: 'Item updated' });
    });
  }

  // 🛑 Invalid Request
  else {
    res.status(400).json({ error: 'Invalid request: missing or incorrect fields' });
  }
});

// ❌ DELETE: Remove Inventory Item
router.delete('/inventory/items/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM inventory WHERE id = ?';
  db.query(sql, [id], (err) => {
    if (err) {
      console.error('❌ Error deleting inventory item:', err);
      return res.status(500).json({ error: 'Failed to delete inventory item' });
    }
    res.json({ message: 'Inventory item deleted successfully' });
  });
});

// 🔍 GET: View Single Item
router.get('/inventory/items/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'SELECT * FROM inventory WHERE id = ?';
  db.query(sql, [id], (err, results) => {
    if (err) {
      console.error('❌ Error fetching item:', err);
      return res.status(500).json({ error: 'Failed to retrieve item' });
    }
    if (results.length === 0) {
      return res.status(404).json({ error: 'Item not found' });
    }
    res.json(results[0]);
  });
});

// 📌 POST: Manual Log Entry (if needed separately)
router.post('/inventory/logs', (req, res) => {
  const { product_id, change_type, quantity_changed, user_id } = req.body;

  if (!product_id || !change_type || quantity_changed == null || !user_id) {
    return res.status(400).json({ error: 'All fields are required.' });
  }

  const sql = `
    INSERT INTO inventory_log (product_id, change_type, quantity_changed, timestamp, user_id)
    VALUES (?, ?, ?, NOW(), ?)
  `;
  db.query(sql, [product_id, change_type, quantity_changed, user_id], (err, result) => {
    if (err) {
      console.error('❌ Error inserting log:', err);
      return res.status(500).json({ error: 'Failed to record inventory log' });
    }
    res.status(201).json({ message: 'Inventory log recorded', log_id: result.insertId });
  });
});

// 🚨 GET: Low Stock Items Based on Reorder Threshold

router.get('/inventory/low-stock', (req, res) => {
  const sql = `
    SELECT id AS product_id, name AS product_name, sku, location, quantity, reorder_threshold
    FROM inventory
    WHERE quantity <= reorder_threshold
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error('❌ Error fetching low stock items:', err);
      return res.status(500).json({ error: 'Database error' });
    }

    res.status(200).json(results);
  });
});



module.exports = router;
