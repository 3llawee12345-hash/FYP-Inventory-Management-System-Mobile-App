const express = require('express');
const router = express.Router();
const db = require('../config/db');  // Make sure your DB config is correct

// GET: Fetch all shipments
router.get('/shipping', (req, res) => {
  const sql = `SELECT * FROM shipments ORDER BY shipment_id DESC`;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching shipments:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
});

// POST: Create a new shipment
router.post('/shipping', (req, res) => {
  const { order_id, shipping_method, quantity, due_date, status, assigned_to } = req.body;

  if (!order_id || !shipping_method ||  !quantity || !due_date || !status) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const sql = `
    INSERT INTO shipments (order_id, shipping_method, quantity, due_date, status, assigned_to)
    VALUES (?, ?, ?, ?, ?, ?)
  `;
  db.query(sql, [order_id, shipping_method, quantity, due_date, status, assigned_to || null], (err, result) => {
    if (err) {
      console.error('Error creating shipment:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ message: 'Shipment created successfully', shipment_id: result.insertId });
  });
});

// PUT: Update an existing shipment
router.put('/shipping/:id', (req, res) => {
  const { id } = req.params;
  const { order_id, shipping_method, quantity, due_date, status, assigned_to } = req.body;

  if (!order_id || !shipping_method || !quantity || !due_date || !status) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const sql = `
    UPDATE shipments
    SET order_id = ?, shipping_method = ?, quantity = ?, due_date = ?, status = ?, assigned_to = ?
    WHERE shipment_id = ?
  `;
  db.query(sql, [order_id, shipping_method, quantity, due_date, status, assigned_to || null, id], (err) => {
    if (err) {
      console.error('Error updating shipment:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ message: 'Shipment updated successfully' });
  });
});

// DELETE: Remove a shipment
router.delete('/shipping/:id', (req, res) => {
  const { id } = req.params;
  const sql = `DELETE FROM shipments WHERE shipment_id = ?`;
  db.query(sql, [id], (err) => {
    if (err) {
      console.error('Error deleting shipment:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ message: 'Shipment deleted successfully' });
  });
});

module.exports = router;
