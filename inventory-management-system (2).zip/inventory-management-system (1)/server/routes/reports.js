// routes/reports.js

const express = require("express");
const router = express.Router();
const db = require("../config/db"); // MySQL connection

// Route 1: Sales by Category
router.get("/reports/sales-by-category", (req, res) => {
  const sql = `
    SELECT p.category, SUM(oi.quantity * oi.price) AS total_sales
    FROM order_items oi
    JOIN products p ON p.product_id = oi.product_id
    GROUP BY p.category
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error fetching sales by category:", err);
      return res.status(500).json({ error: "Server error" });
    }

    // ✅ Always respond with an array
    if (!Array.isArray(results)) {
      return res.json([]);
    }

    res.json(results);
  });
});


// Route 2: Inventory Distribution
router.get("/reports/inventory-distribution", (req, res) => {
  const sql = `
    SELECT status, COUNT(*) AS count
    FROM inventory
    GROUP BY status
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error("Error fetching inventory distribution:", err);
      return res.status(500).json({ error: "Server error" });
    }
    res.json(results);
  });
});

module.exports = router;
