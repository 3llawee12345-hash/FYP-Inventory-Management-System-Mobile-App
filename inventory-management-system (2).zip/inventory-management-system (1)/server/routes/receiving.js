const express = require('express');
const router = express.Router();
const db = require('../config/db');

// GET all receipts with linked order info
router.get('/receiving', (req, res) => {
  const sql = `
    SELECT 
      receipts.receipt_id,
      receipts.order_id,
      orders.customer_id,
      receipts.supplier_name,
      receipts.expected_date,
      receipts.quantity,
      receipts.status,
      receipts.assigned_to
    FROM receipts
    LEFT JOIN orders ON receipts.order_id = orders.order_id
    ORDER BY receipts.receipt_id DESC
  `;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error fetching receipts:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json(results);
  });
});

// POST Create a new receipt
router.post('/receiving', (req, res) => {
  const { order_id, supplier_name, expected_date, quantity, status, assigned_to } = req.body;

  if (!order_id || !supplier_name || !expected_date ||  !quantity || !status) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const sql = `
    INSERT INTO receipts (order_id, supplier_name, expected_date, quantity, status, assigned_to)
    VALUES (?, ?, ?, ?, ?, ?)
  `;
  db.query(sql, [order_id, supplier_name, expected_date, quantity, status, assigned_to || null], (err, result) => {
    if (err) {
      console.error('Error adding receipt:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ message: 'Receipt created successfully', receipt_id: result.insertId });
  });
});

// PUT Update receipt (Fixed route path syntax)
router.put('/receiving/:id', (req, res) => {
  const { id } = req.params;
  const { order_id, supplier_name, expected_date, quantity, status, assigned_to } = req.body;

  const sql = `
    UPDATE receipts
    SET order_id = ?, supplier_name = ?, expected_date = ?, quantity = ?, status = ?, assigned_to = ?
    WHERE receipt_id = ?
  `;
  db.query(sql, [order_id, supplier_name, expected_date, quantity, status, assigned_to || null, id], (err) => {
    if (err) {
      console.error('Error updating receipt:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ message: 'Receipt updated successfully' });
  });
});

// DELETE receipt (Fixed route path syntax)
router.delete('/receiving/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM receipts WHERE receipt_id = ?';
  db.query(sql, [id], (err) => {
    if (err) {
      console.error('Error deleting receipt:', err);
      return res.status(500).json({ error: 'Database error' });
    }
    res.json({ message: 'Receipt deleted successfully' });
  });
});

module.exports = router;
