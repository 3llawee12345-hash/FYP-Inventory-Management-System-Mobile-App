const express = require('express');
const router = express.Router();
const db = require('../config/db');

/**
 * @route   GET /api/inventory/scan/:sku
 * @desc    Fetch product details by SKU (no update, no log)
 */
router.get('/inventory/scan/:sku', (req, res) => {
  const sku = req.params.sku;

  if (!sku || typeof sku !== 'string' || sku.trim() === '') {
    return res.status(400).json({ error: 'Invalid SKU' });
  }

  const fetchSql = 'SELECT sku, name, quantity, location FROM inventory WHERE sku = ?';
  db.query(fetchSql, [sku], (err, results) => {
    if (err) {
      console.error('❌ Database error:', err);
      return res.status(500).json({ error: 'Error fetching product from database' });
    }

    if (results.length === 0) {
      return res.status(404).json({ error: `Product not found for SKU: ${sku}` });
    }

    const product = results[0];
    res.status(200).json(product);
  });
});

module.exports = router;
