const express = require('express');
const router = express.Router();
const mysql = require('mysql2');
const jwt = require('jsonwebtoken');

// ✅ JWT secret key (store in .env in production)
const JWT_SECRET = 'yourSecretKey';

// ✅ MySQL Connection
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '', // your DB password
  database: 'inventory_system'
});

// ✅ Middleware: Authenticate JWT Token
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Token missing' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ message: 'Invalid or expired token' });
    req.user = user;
    next();
  });
}

// ✅ Login Route
router.post('/login', (req, res) => {
  const { email, password, role } = req.body;

  const sql = 'SELECT * FROM users WHERE email = ? AND password = ?';
  db.query(sql, [email, password], (err, results) => {
    if (err) {
      console.error('MySQL Error:', err);
      return res.status(500).json({ message: 'Server error' });
    }

    if (results.length === 0) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const user = results[0];
    const dbRole = user.role.toLowerCase();
    const selectedRole = role.toLowerCase();
    if (dbRole !== selectedRole) {
      return res.status(403).json({ message: 'Role not recognized or mismatched' });
    }

    // ✅ Generate JWT token
    const token = jwt.sign(
      {
        id: user.user_id,
        email: user.email,
        role: dbRole,
        name: user.name
      },
      JWT_SECRET,
      { expiresIn: '1h' }
    );

    return res.status(200).json({ token, role: dbRole });
  });
});

// ✅ GET User Info via JWT
router.get('/auth/user', authenticateToken, (req, res) => {
  const { id, email, role, name } = req.user;
  res.status(200).json({ id, email, role, name });
});

module.exports = { router, authenticateToken };
