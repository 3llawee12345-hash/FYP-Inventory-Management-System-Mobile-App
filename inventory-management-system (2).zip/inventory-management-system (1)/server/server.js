// server.js (Fully Updated)

const express = require('express');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;


// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Import Routes
const {router} = require('./middleware/auth');
const registerRoutes = require('./routes/register');
const inventoryRoutes = require('./routes/inventory');
const warehouseInventory = require('./routes/warehouseInventory');
const productsRoutes = require('./routes/Products'); // Fixed and updated products route
const customersRoutes = require('./routes/customers');
const ordersRoutes = require('./routes/orders');
const reportsRoutes = require('./routes/reports');
const receivingRoutes = require('./routes/receiving');
const shippingRoutes = require('./routes/shipping');
const invoicesRoutes = require('./routes/invoices');
const scanRoutes = require('./routes/scan');
const dashboardRoutes = require('./routes/dashboard');

// Use Routes (Under /api)
app.use('/api', router);
app.use('/api', registerRoutes);
app.use('/api', inventoryRoutes);
app.use('/api', warehouseInventory);
app.use('/api', productsRoutes); 
app.use('/api', customersRoutes);
app.use('/api', ordersRoutes);
app.use('/api', reportsRoutes);
app.use('/api', receivingRoutes);
app.use('/api', shippingRoutes);
app.use('/api', invoicesRoutes);
app.use('/api', scanRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use(express.json());


// Main HTML page (default route)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/Pages/index.html'));
});

// 404 Handler (If no route matched)
app.use((req, res) => {
  res.status(404).send('404 - Page Not Found');
});

// Error Handler Middleware (Optional but recommended)
app.use((err, req, res, next) => {
  console.error('Server Error:', err.stack);
  res.status(500).send('Something broke! Please try again later.');
});




// Start Server
app.listen(PORT, () => {
  console.log(`✅ Server running at: http://localhost:${PORT}`);
});
