const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // or your username
  password: '', // your database password
  database: 'inventory_system' // your database name
});

db.connect((err) => {
    if (err) {
      console.error('Database connection error:', err);
      throw err;
    }
    console.log('Connected to MySQL database ✅');
  });

module.exports = db;
